NUGG_ABAB2XLS_UTILS620.nugg

Classes necessary to run abap2xlsx on basis 6.20

Work only as of release 2.1 (check daily bouild)

Instalation procedure:

1. Use ZSAPLINK to install NUGG_ABAB2XLS_UTILS620.nugg

2. Open NUGG_ABAP2XLSX_V_xxx.nugg in text editor and do search and replace 
according to following table:
Search                Replace with  
CL_OBJECT_COLLECTION	ZCL_OBJECT_COLLECTION
IF_OBJECT_COLLECTION	ZIF_OBJECT_COLLECTION
CL_ABAP_ZIP	          ZCL_ABAP_ZIP
  
3. Use ZSAPLINK to install modified NUGG_ABAP2XLSX_V_xxx.nugg

4. Activate all objects